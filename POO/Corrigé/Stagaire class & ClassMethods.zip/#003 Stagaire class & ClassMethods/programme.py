from stagaire import *

#crier 4 stagiare
for i in range(4):
    Stagaire.ajoute()

##affiche
Stagaire.affiche()

#affiche note >= 10 valide stagaire
Stagaire.valideStagaire()

#Moyanne
Stagaire.moynneNote()

#chreche un stagaire
Stagaire.cherche()

#modifier un note
Stagaire.modifierNote()

#sump un stagaire 
Stagaire.supprimerStagaire()

#affiche le nomber de stagaire
Stagaire.nombreOfStagaire()
